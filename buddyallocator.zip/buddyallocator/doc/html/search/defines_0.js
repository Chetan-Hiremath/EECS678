var searchData=
[
  ['addr_5fto_5fpage_131',['ADDR_TO_PAGE',['../buddy_8c.html#aa44fbfb588ad3483e93dfc7fd28b2afd',1,'buddy.c']]]
];
