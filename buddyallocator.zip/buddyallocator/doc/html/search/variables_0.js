var searchData=
[
  ['block_5faddress_106',['block_address',['../structpage__t.html#ab5435cd25d4e2608a16d6d206b1f5565',1,'page_t']]],
  ['block_5fsize_5forder_107',['block_size_order',['../structpage__t.html#af21ef86d91f457226d8525077e197237',1,'page_t']]]
];
