var searchData=
[
  ['get_5fvar_88',['get_var',['../simulator_8c.html#a8243708bf20349942fd78b86b23faa38',1,'simulator.c']]]
];
