var searchData=
[
  ['g_5fmemory_109',['g_memory',['../buddy_8c.html#ad6d688a63e574ba24b0247b2bec1e31d',1,'buddy.c']]],
  ['g_5fpages_110',['g_pages',['../buddy_8c.html#afbc14d1f5ec9e22ef3e00d9d33ee0c08',1,'buddy.c']]]
];
