var searchData=
[
  ['ifdebug_20',['IFDEBUG',['../buddy_8c.html#abcf0d5a50dd7e407cd464c1afbd27554',1,'buddy.c']]],
  ['in_21',['in',['../simulator_8c.html#aca392a8d3941cd0740aef3ad92545d67',1,'simulator.c']]],
  ['in_5fuse_22',['in_use',['../structvar__t.html#ac304039a94e589f7d11f4ec3353abab4',1,'var_t']]],
  ['index_23',['index',['../structpage__t.html#a006523076a191dd2fa60e23b2dfa6ef2',1,'page_t']]],
  ['init_5flist_5fhead_24',['INIT_LIST_HEAD',['../list_8h.html#a0ffe9d28c36d7b018a9cfae33bae45c0',1,'list.h']]]
];
