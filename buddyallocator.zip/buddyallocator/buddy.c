/**
 * Buddy Allocator
 *
 * For the list library usage, see http://www.mcs.anl.gov/~kazutomo/list/
 */

/**************************************************************************
 * Conditional Compilation Options
 **************************************************************************/
#define USE_DEBUG 0

/**************************************************************************
 * Included Files
 **************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#include "buddy.h"
#include "list.h"

/**************************************************************************
 * Public Definitions
 **************************************************************************/
#define MIN_ORDER 12
#define MAX_ORDER 20

#define PAGE_SIZE (1<<MIN_ORDER)
/* page index to address */
#define PAGE_TO_ADDR(page_idx) (void *)((page_idx*PAGE_SIZE) + g_memory)

/* address to page index */
#define ADDR_TO_PAGE(addr) ((unsigned long)((void *)addr - (void *)g_memory) / PAGE_SIZE)

/* find buddy address */
#define BUDDY_ADDR(addr, o) (void *)((((unsigned long)addr - (unsigned long)g_memory) ^ (1<<o)) \
									 + (unsigned long)g_memory)

#if USE_DEBUG == 1
#  define PDEBUG(fmt, ...) \
	fprintf(stderr, "%s(), %s:%d: " fmt,			\
		__func__, __FILE__, __LINE__, ##__VA_ARGS__)
#  define IFDEBUG(x) x
#else
#  define PDEBUG(fmt, ...)
#  define IFDEBUG(x)
#endif

/**************************************************************************
 * Public Types
 **************************************************************************/
typedef struct {
	struct list_head list;
	/* TODO: DECLARE NECESSARY MEMBER VARIABLES */
    int block_size_order;
	int block_index;
	char *block_address;
} page_t;

/**************************************************************************
 * Global Variables
 **************************************************************************/
/* free lists*/
struct list_head free_area[MAX_ORDER+1];

/* memory area */
char g_memory[1<<MAX_ORDER];

/* page structures */
page_t g_pages[(1<<MAX_ORDER)/PAGE_SIZE];

/**************************************************************************
 * Public Function Prototypes
 **************************************************************************/

/**************************************************************************
 * Local Functions
 **************************************************************************/

/**
 * Initialize the buddy system
 */
void buddy_init()
{
	int i;
	int n_pages = (1<<MAX_ORDER) / PAGE_SIZE;
	for (i = 0; i < n_pages; i++) 
	{
		/* TODO: INITIALIZE PAGE STRUCTURES */
		INIT_LIST_HEAD(&g_pages[i].list);
		g_pages[i].block_size_order = -1;
		g_pages[i].block_index = i;
		g_pages[i].block_address = PAGE_TO_ADDR(i);
	}
	g_pages[0].block_size_order = MAX_ORDER;
	
	/* initialize freelist */
	for (i = MIN_ORDER; i <= MAX_ORDER; i++) 
	{
		INIT_LIST_HEAD(&free_area[i]);
	}

	/* add the entire memory as a freeblock */
	list_add(&g_pages[0].list, &free_area[MAX_ORDER]);
}

/**
 * Allocate a memory block.
 *
 * On a memory request, the allocator returns the head of a free-list of the
 * matching size (i.e., smallest block that satisfies the request). If the
 * free-list of the matching block size is empty, then a larger block size will
 * be selected. The selected (large) block is then splitted into two smaller
 * blocks. Among the two blocks, left block will be used for allocation or be
 * further splitted while the right block will be added to the appropriate
 * free-list.
 *
 * @param size size in bytes
 * @return memory block address
 */
void *buddy_alloc(int size)
{
	/* TODO: IMPLEMENT THIS FUNCTION */
#if USE_DEBUG
	printf("Attempt of buddy_alloc function with the size of %i bytes.\n", size);
#endif
	if((size > (1 << MAX_ORDER)) || (size <= 0))
	{
	#if USE_DEBUG
		printf("Error: Invalid allocation request: %i is not a valid size\n", size);
	#endif
		return NULL;
	}
	int size_order = MIN_ORDER, i;
	while((size_order <= MAX_ORDER) && ((1 << size_order) < size)) 
	{
		size_order++;
	}
#if USE_DEBUG
	printf("Size is %i in the order of %i\n", size, size_order);
#endif
	for(i = size_order; i <= MAX_ORDER; i++) 
	{
		if(!(list_empty(&free_area[i])))
		{
		#if USE_DEBUG
			printf("There's an empty block of order %i, so the program's partitioning...\n", i);
		#endif
			page_t *left_block, *right_block;
			int request_page_index;
			void *request_page_address;
			if(i == size_order) 
			{
			#if USE_DEBUG
				printf("The block of order %i, is partitioned, so the program's returning the address...\n", i);
			#endif
				left_block = list_entry(free_area[i].next, page_t, list);
				list_del(&(left_block->list));
			}
			else 
			{
				#if USE_DEBUG
					printf("Recursion starts...\n");
				#endif
				left_block = &g_pages[ADDR_TO_PAGE(buddy_alloc((1 << (size_order + 1))))];
				request_page_index = left_block->block_index + ((1 << size_order) / PAGE_SIZE);
				right_block = &g_pages[request_page_index];
				list_add(&(right_block->list), &free_area[size_order]);
			}
			left_block->block_size_order = size_order;
			request_page_address = PAGE_TO_ADDR(left_block->block_index);
			return request_page_address;
		}
	}
	return NULL;
}

/**
 * Free an allocated memory block.
 *
 * Whenever a block is freed, the allocator checks its buddy. If the buddy is
 * free as well, then the two buddies are combined to form a bigger block. This
 * process continues until one of the buddies is not free.
 *
 * @param addr memory block address to be freed
 */
void buddy_free(void *addr)
{
	/* TODO: IMPLEMENT THIS FUNCTION */
#if USE_DEBUG
	printf("Attempt of buddy_free function with the address of %p\n", addr);
#endif
	int request_page_index = ADDR_TO_PAGE(addr);
	int request_page_order = g_pages[request_page_index].block_size_order;
	page_t *temp_block;
	struct list_head *current;
	for(;;request_page_order++) 
	{
		temp_block = NULL;
		list_for_each(current, &free_area[request_page_order]) 
		{
			temp_block = list_entry(current, page_t, list);
			if(temp_block == NULL)
			{
				break;
			}
			else if(temp_block->block_address == BUDDY_ADDR(addr, request_page_order))
			{
				break;
			}
		}		
		if(temp_block == NULL) 
		{
			g_pages[request_page_index].block_size_order = -1;
			list_add(&g_pages[request_page_index].list, &free_area[request_page_order]);
			return;
		}
		else if(temp_block->block_address != BUDDY_ADDR(addr, request_page_order)) 
		{
			g_pages[request_page_index].block_size_order = -1;
			list_add(&g_pages[request_page_index].list, &free_area[request_page_order]);
			return;
		}
		if((char*) addr > temp_block->block_address) 
		{
			addr = temp_block->block_address;
			request_page_index = ADDR_TO_PAGE(addr);
		}
		list_del(&(temp_block->list));
	}
}

/**
 * Print the buddy system status---order oriented
 *
 * print free pages in each order.
 */
void buddy_dump()
{
	int o;
	for (o = MIN_ORDER; o <= MAX_ORDER; o++) 
	{
		struct list_head *pos;
		int cnt = 0;
		list_for_each(pos, &free_area[o]) 
		{
			cnt++;
		}
		printf("%d:%dK ", cnt, (1<<o)/1024);
	}
	printf("\n");
}
