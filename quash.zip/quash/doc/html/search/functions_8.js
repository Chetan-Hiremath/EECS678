var searchData=
[
  ['new_5fdestructable_5fexample_178',['new_destructable_Example',['../group__DEQUE.html#ga4a210705b6f22fe97b7033bb8854a4d6',1,'deque.h']]],
  ['new_5fexample_179',['new_Example',['../group__DEQUE.html#gae0c6f52c89e2b087e19e3062186144da',1,'deque.h']]]
];
